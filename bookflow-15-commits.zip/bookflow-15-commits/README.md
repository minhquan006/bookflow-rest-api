# Chia lại BookFlow: 5 commit hoàn chỉnh mỗi thành viên

## Hiện trạng đã đối chiếu

Ngày 23/10/2026, GitHub main vẫn ở foundation `6b2404c`; Auth ở `f33bd6b` có 2 commit trên foundation, Catalog thật của Tú ở `1bdf367` có 17 commit. Chưa thấy nhánh Loans trên remote. Nhánh `codex/tu-bookflow-handoff-20261022@2394e04` có cấu trúc Catalog/Auth khác dòng các gói zip, không dùng làm nền của bộ chia này. Các nhánh cũ được giữ nguyên, không push/reset/force push.

Đã đọc đề DOCX, blueprint, bản bàn giao và các manifest/patch trong ba zip. Checksum của 127 file gói Quân, 6 file gói Tú, 5 file gói An đều khớp. Link hội thoại ChatGPT bị proxy trả 403; không coi nội dung link là đã đọc. Đề yêu cầu demo REST, báo cáo và cộng tác; ít nhất 5 commit/người là yêu cầu của Quân trong cuộc trò chuyện này.

## Bộ chia mới

- `quan-auth-users/`: 5 patch từ foundation → đúng snapshot Auth `e15fc74f...`.
- `tu-catalog/`: 5 patch từ Auth → đúng snapshot Catalog đã ghép `d41fa35b...`; bao gồm cả code gốc của Tú, không chỉ patch bổ sung 21 file. Gói mới thay hướng dẫn dùng bundle cũ trong luồng chia lại này.
- `an-loans/`: 5 patch từ Catalog hoàn chỉnh → đúng snapshot cuối `b2d270ee...`.

Mỗi thư mục chứa `01.patch`–`05.patch`, manifest file cho từng bước, `series.json`, README và script tạo từng commit. Script dùng Git identity hiện có của người chạy, kiểm tra tree nền và trạng thái sạch, áp một bước, chạy check/integration/E2E rồi commit. Không đặt author/date và không tự push. README có lệnh push riêng sau mỗi bước để mỗi người kiểm tra trước khi gửi lên GitHub.

Các bước tách theo module độc lập. Một số component được thêm trước, qua build/typecheck và kiểm tra tích lũy; điều hướng và test màn hình được ghép ở bước sau; không phải mọi bước đều thêm một nút mới trên UI. Tài liệu/chứng cứ đi cùng mốc cuối của mỗi phần, không tạo file rỗng để đủ số commit.

## Nhánh local và quyền tác giả

`feat/auth-users-split` có 5 commit dùng Git identity Quân đang cấu hình trên máy. `review/tu-catalog-split` và `review/an-loans-split` chỉ là nhánh chuẩn bị kỹ thuật với author `Codex Preparation`, phục vụ kiểm thử; KHÔNG push chúng như đóng góp của Tú/An. Tú/An dùng patch và script từ nhánh main đúng nền để tự tạo commit sau khi đọc/kiểm thử. Không gán commit của Quân hoặc Codex sang tên người khác.

## Thứ tự làm và merge

1. Quân dùng nhánh split đã chuẩn bị hoặc tự replay gói trên nhánh mới (chọn một cách, không tạo hai PR cho cùng phần). Review rồi push từng mốc; nhờ Tú review.
2. Merge Auth vào main bằng Create a merge commit, không squash. Tú pull main, chạy từng bước gói Tú, push bằng Git của Tú; nhờ An review.
3. Merge Catalog theo cùng cách. An pull main, chạy từng bước gói An, push bằng Git của An; nhờ Quân review.
4. Kiểm tra main có đủ thay đổi, chạy toàn bộ check/integration/E2E. Dùng `git log --no-merges --oneline origin/main..HEAD` trước PR để đếm đúng 5 commit riêng.

Không merge lại nhánh Auth/Catalog cũ sau khi đã merge dòng chia mới. Chúng được giữ làm tham chiếu. Nếu main hoặc nhánh thành viên có thay đổi mới, script sẽ dừng khi tree nền không khớp; cập nhật gói/hòa giải thay đổi thay vì reset. Nếu muốn giữ đủ 5 commit trên main, tránh Squash and merge.

## Kiểm thử và bằng chứng

Kết quả chạy mới nằm trong `validation.json`, `runtime-validation.json` và thư mục `logs/` của gói tổng. Các số liệu trong docs/evidence và tài liệu cũ vẫn là kết quả bàn giao trước; không tự coi là kết quả của từng thành viên. Không đưa .env, mật khẩu, node_modules, database hay credential vào các gói phát hành.
