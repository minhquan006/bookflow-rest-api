# BookFlow team handoff — current delivery

Auth/Users (PR #4) and Catalog/Copies (PR #5, including the review correction) are merged into main `50e2dc4`. Use `an-loans-v2/` for the next member workflow. It replaces the obsolete An v1 package. Quân/Tú folders are retained as historical handoff references; their work is already merged and should not be replayed onto current main.

Read `an-loans-v2/README.md` for clean-machine setup and individual review/commit/push instructions. The expected base tree is pinned; do not bypass this check if main changes. An creates commits with their own identity after review and testing; verification branches are technical preparation only.

Current command receipts are in `an-loans-v2/VALIDATION.md`, validation.json and logs/. Final integration passes 66 server + 71 client tests, 105 PostgreSQL tests and 22 browser cases. Old logs under historical/ describe the earlier handoff, not the current v2 build. The standalone source ZIP is for running/reading the assembled application and contains no Git history; use the repository plus patches for the team commit workflow.
