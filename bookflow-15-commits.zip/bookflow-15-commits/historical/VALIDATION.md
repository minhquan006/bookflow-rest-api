# Kết quả xác thực bộ chia 15 commit

Tất cả 15 mốc đều đạt `npm run check`, `npm run test:integration` và `npm run test:e2e`. Với mốc có tree không đổi và đã đạt check ở lượt đầu, kết quả check được tái sử dụng theo đúng tree; integration/E2E đã chạy lại trên từng mốc.

| Phần (mốc 5) | Server unit/HTTP | Client component/unit | PostgreSQL integration | E2E desktop/mobile |
|---|---:|---:|---:|---:|
| quan-auth-users | 52 | 32 | 28 | 10 |
| tu-catalog | 66 | 59 | 87 | 18 |
| an-loans | 66 | 71 | 105 | 20 |


Đây là kiểm tra native dev stack với PostgreSQL Docker và Chromium có sẵn, không phải chạy lại Docker API/web, Newman hoặc benchmark. Số đo benchmark và ảnh/log có sẵn trong patch cuối là chứng cứ bàn giao cũ. Không dùng chúng để tuyên bố một lần đo mới.

Các script self-commit đã được kiểm tra cú pháp; 15 patch đã replay qua Git index và khớp tree từng mốc. Nhánh kiểm thử được tạo bằng Git commit-tree; script self-commit của thành viên chưa được chạy end-to-end để tạo thêm một bộ commit trùng lặp.

GitHub chỉ được đọc/fetch, chưa push hoặc mở/merge PR. `work` được khôi phục sau khi kiểm thử; mã nguồn checkout không có thay đổi chưa commit.
