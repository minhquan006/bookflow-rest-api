# Quân: push 5 mốc đã chuẩn bị trên cloud

Chỉ dùng trong checkout cloud hiện tại, sau khi review kết quả kiểm thử. Đây là phương án thay cho việc replay gói Quân trên máy cá nhân; không làm đồng thời cả hai cách. Các nhánh GitHub cũ chưa bị thay đổi.

Git identity của 5 commit này là `Quan Nguyen <quannguyen2342006@gmail.com>` (cấu hình hiện có), không phải identity của Tú hoặc An.

Kiểm tra remote và 5 commit trước:

```bash
cd /workspace/bookflow-rest-api
git log --reverse --format="%h %an %s" 6b2404c..feat/auth-users-split
git ls-remote --heads origin feat/auth-users-split
```

Nếu nhánh remote chưa có, push lần lượt. Nếu đã tồn tại với lịch sử khác, dừng và đối chiếu; không force push.

```bash
git push origin 25e39b687881352030bd05954c3bc279ef7261e2:refs/heads/feat/auth-users-split
git push origin 8c96165b2faaacc197e86b1ebf43593a0e20d9e9:refs/heads/feat/auth-users-split
git push origin a7e637d211ec52727edba6c2fc72147f5f68df35:refs/heads/feat/auth-users-split
git push origin 66cbd9e2b500da56a6c6e73fe400a051f00c474e:refs/heads/feat/auth-users-split
git push origin 99b624619b9079bbf224056f072f968119d5f0f8:refs/heads/feat/auth-users-split
```

Mỗi dòng là một lần push; chỉ chạy dòng tiếp theo sau khi dòng trước thành công. Sau dòng đầu có thể mở PR vào main và tiếp tục cập nhật PR bằng các push kế tiếp. Review diff và CI của từng mốc. Cuối cùng dùng Create a merge commit để giữ đủ 5 commit trên main. Không merge thêm PR Auth cũ cho cùng thay đổi.
