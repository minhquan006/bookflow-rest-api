# An — Loans/Dashboard/Audit, bản v2

Gói này thay gói An cũ sau khi PR #5 đã merge. Nền yêu cầu là main `50e2dc4`
(tree `95da85a3833ec188d8f76dfec04bba58896162fa`), có Auth/Users và Catalog đã sửa
phần UI mượn chưa triển khai. Không trộn các file v1 và v2 trong cùng thư mục.

Các patch không mang metadata tác giả. An cần đọc, chạy, review/chỉnh sửa và giải
thích được mã; script dùng Git identity của người chạy, không đặt author/date,
không tự push và không sửa các nhánh đã có. Nội dung có AI hỗ trợ; xem
`docs/AI_ASSISTANCE.md` trong source.

## Chuẩn bị máy và repository

Cài Git, Node 24.19.0/npm 11 và Docker Desktop/Engine. Mở Docker, chờ sẵn sàng.
Nếu chưa có repository, chạy từ thư mục làm việc:

```bash
git clone https://github.com/minhquan006/bookflow-rest-api.git
cd bookflow-rest-api
```

Nếu repository private, Quân cần cấp quyền collaborator cho tài khoản GitHub của
An. Giải nén gói bên ngoài checkout, ví dụ:

```text
thu-muc-lam-viec/
  bookflow-rest-api/
  an-loans-v2/
```

Tất cả lệnh tiếp theo chạy ở root `bookflow-rest-api`. Nếu có công việc chưa lưu,
lưu lại trước khi đổi nhánh; không reset/force push để bỏ qua lỗi.

```bash
git status --short
git switch main
git pull --ff-only origin main
git log -1 --oneline
node --version
npm --version
git config user.name
git config user.email
```

Trạng thái cần sạch, Node đúng phiên bản; name/email phải là của An, email đã
liên kết GitHub. Script kiểm tra chính xác tree nền và sẽ dừng nếu main có thêm
thay đổi sau mốc đóng gói. Khi đó liên hệ Quân để hòa giải/cập nhật gói; không
sửa `series.json` để vượt kiểm tra.

## Cài và khởi động dịch vụ

```bash
npm ci && npm run deps && npm run setup
```

```bash
docker compose up -d --wait db &&
npm --prefix server run build &&
npm run db:migrate &&
npm run db:seed &&
npm run db:test:create
```

```bash
npx playwright install chromium
```

Cấu hình và mật khẩu local được sinh trên máy An. Nếu setup giữ file .env cũ,
đối chiếu DATABASE_URL/TEST_DATABASE_URL ở root và server để bảo đảm dùng đúng DB.
Test DB phải có tên kết thúc `_test`. Không gửi .env/token, không commit node_modules
hoặc dump DB, không dùng `docker compose down -v`.

Mặc định DB/API/web dùng 5432/3000/5173. Nếu bị chiếm cổng, dừng và gửi log; không
dừng ứng dụng khác khi chưa xác định. Trên Mac có thể dùng helper
`bookflow-mac-dev.mjs` trên nhánh `delivery/bookflow-download` cho API 3100/web 5174.
Khi dùng helper, giữ nó chạy ở Terminal riêng và trong Terminal chạy script đặt:

```bash
export E2E_EXTERNAL=1
export E2E_BASE_URL=http://127.0.0.1:5174
export NO_PROXY="${NO_PROXY:+$NO_PROXY,}127.0.0.1,localhost,::1"
export no_proxy="${no_proxy:+$no_proxy,}127.0.0.1,localhost,::1"
```

Chỉ dùng các export trên nếu helper thực sự đang chạy. DB 5433, nếu cần, phải được
cấu hình riêng theo hướng dẫn local; helper không đổi cấu hình DB.

## Thực hiện từng bước

Đọc `NN.files.txt` và `NN.patch` tương ứng trước mỗi bước. Lệnh script áp một
patch, chạy check/integration/E2E rồi mới tạo commit nếu tất cả đạt.

| Bước | Phạm vi                                                                   |
| ---- | ------------------------------------------------------------------------- |
| 1    | Loans/Dashboard/Audit API, Postman/contract và test PostgreSQL            |
| 2    | Giao diện phiếu mượn cho MEMBER/staff và component tests                  |
| 3    | Giao diện Dashboard/Audit và component tests                              |
| 4    | Ghép điều hướng, khôi phục Borrow/My loans khi API đã có, test luồng thật |
| 5    | Script benchmark và tài liệu bàn giao/validation                          |

Nếu hai thư mục nằm cạnh nhau như ví dụ, chạy:

```bash
node "../an-loans-v2/commit-step.mjs" 1
```

Bước đầu tự tạo nhánh `feat/an-loans-5commits`. Sau khi script thành công, review:

```bash
git show --stat HEAD
git show HEAD
```

Nhấn q để thoát diff. Sau khi review, push:

```bash
git push -u origin feat/an-loans-5commits
```

Tiếp tục chạy cùng script với số 2, rồi review/push, sau đó 3, 4, 5 theo cùng cách.
Không chạy toàn bộ số bước bằng vòng lặp hoặc push trước khi đọc kết quả.

Nếu script thất bại, giữ nguyên code/staging và gửi log. Không chạy lại cùng patch
hoặc xóa thay đổi. Sau khi nguyên nhân được sửa và checks đạt, có thể cần commit
phần đã staged bằng tay rồi mới đi tiếp; nhờ Quân đối chiếu tree trước bước sau.

Ở bước 1–3, UI mượn vẫn ẩn dù API đã có. Bước 4 khôi phục đầy đủ cùng với màn
hình Loans, nên không tái tạo lỗi CTA gọi endpoint chưa triển khai của Catalog.
Các test về availability, 304 và xóa cache sau 404 của Tú được giữ; test giao diện
sau tích hợp xác nhận quyền và điều hướng phù hợp, không tự mượn khi chỉ xem sách.

## Nghiệm thu và PR

Tự xác minh giới hạn mượn/overdue/trùng đầu sách, tranh copy cuối và rollback,
ownership của MEMBER, quyền trả của staff, trả lặp không tạo audit trùng,
Dashboard/Audit đúng quyền, và UI không giữ dữ liệu của người trước sau logout.

Khi hoàn tất:

```bash
git fetch origin
git log --reverse --oneline origin/main..HEAD
git rev-list --count origin/main..HEAD
git status --short
```

Nếu main chưa thay đổi thêm, cần 5 commit và working tree sạch. Mở PR từ
`feat/an-loans-5commits` vào main, tiêu đề
`feat(loans): implement borrowing returns and library administration`.
Điền theo template, ghi kết quả An tự chạy, phạm vi AI hỗ trợ và kiểm tra chưa chạy.
Nhờ Quân review, kiểm tra GitHub Actions. Khi đạt, dùng Create a merge commit;
không squash nếu cần giữ lịch sử.

Kết quả cloud của gói này nằm trong VALIDATION.md, validation.json và logs/.
Các kết quả cũ trong docs/evidence/benchmark.json và tài liệu bàn giao khác là lịch
sử của lần chạy trước, không phải benchmark/Postman/Docker mới trên máy An.
