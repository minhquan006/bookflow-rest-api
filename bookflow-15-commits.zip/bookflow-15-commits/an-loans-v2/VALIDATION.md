# Validation — An delivery v2

Prepared against main `50e2dc410e3f2e8146da007f58f71f6c7f7af9a5`, including PR #5 review fix `118d20f`. Catalog base tree: `95da85a3833ec188d8f76dfec04bba58896162fa`.

All five shipped patch steps replay exactly to their recorded Git trees. Every step passed `npm run check`, `npm run test:integration` and `npm run test:e2e` in the cloud workspace with Node 24.19.0/npm 11, Docker PostgreSQL and Chromium. The final step reuses the completed results for the identical final source tree; other steps were executed individually. These are cloud results, not results on An’s machine or GitHub Actions.

| Step | Server unit/HTTP | Client unit/component | PostgreSQL integration | Browser desktop/mobile |
| --- | ---: | ---: | ---: | ---: |
| 1 | 66 | 59 | 105 | 20 |
| 2 | 66 | 66 | 105 | 20 |
| 3 | 66 | 71 | 105 | 20 |
| 4 | 66 | 71 | 105 | 22 |
| 5 | 66 | 71 | 105 | 22 |


## Scope

Steps 1–3 retain the Catalog-only UI boundary from Tú’s fix, despite the backend becoming available in step 1. Step 4 restores borrowing controls and navigation alongside actual Loans screens. Catalog availability, metadata 304 and visibility-after-404 regression tests are retained. The MEMBER browser regression now verifies integrated navigation and no automatic borrowing merely from browsing. The full business browser tests exercise borrow and staff return.

React lint advisories remain; there were no lint errors. Full Docker API/web deployment, Newman and the benchmark were not rerun. Existing source documents and benchmark outputs contain explicitly historical evidence; they do not establish a fresh measurement. The self-commit helper passed syntax validation and the patches were independently replayed; no commits were created as An. Temporary verification commits use Codex Preparation and are not to be pushed as member contributions.

See validation.json and logs/ for command-level results.
