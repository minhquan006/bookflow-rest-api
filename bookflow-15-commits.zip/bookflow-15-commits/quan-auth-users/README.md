# quan-auth-users: 5 commit riêng

Giải nén gói bên ngoài repository. Dùng tài khoản Git của chính bạn; script không đặt author/date, không push và không reset.

Tạo nhánh từ main đã cập nhật, với tree nền khớp chính xác. Thứ tự merge: Quân → Tú → An. Không dùng nhánh Codex handoff khác dòng mã làm nền. Nếu main có thay đổi mới, dừng để hòa giải thay vì ghi đè.

Cài Node 24.19.0/npm 11, chạy `npm ci`, `npm run deps`, `npm run setup`, khởi động PostgreSQL theo README, build server, migrate/seed và tạo DB test. Cài Chromium theo README. Trên cloud đặt `npm_config_cache=/workspace/.npm-cache` khi cài dependencies.

Chạy từng bước từ root repository. Đọc `NN.files.txt` và `NN.patch` trước khi áp dụng. Mỗi lệnh chỉ tạo một commit sau khi check/integration/E2E đạt. Khi check lỗi, script giữ thay đổi staged để bạn chẩn đoán; không chạy lại patch hoặc xóa công việc. Sau khi sửa, tự chạy lại checks và commit đúng phần đã review.

| Bước | Commit |
|---|---|
| 1 | `feat(auth): implement secure sessions and users API with PostgreSQL tests` |
| 2 | `feat(auth-ui): add session provider and login registration forms` |
| 3 | `feat(users-ui): add administrator user management and tests` |
| 4 | `feat(auth-ui): connect account screens and verify browser flows` |
| 5 | `docs(auth): document security behavior setup and handoff` |

```bash
git switch main
git pull --ff-only origin main
# Thay /path bằng đường dẫn đến gói đã giải nén.
node "/path/quan-auth-users/commit-step.mjs" 1
git push -u origin feat/quan-auth-users-5commits
node "/path/quan-auth-users/commit-step.mjs" 2
git push -u origin feat/quan-auth-users-5commits
node "/path/quan-auth-users/commit-step.mjs" 3
git push -u origin feat/quan-auth-users-5commits
node "/path/quan-auth-users/commit-step.mjs" 4
git push -u origin feat/quan-auth-users-5commits
node "/path/quan-auth-users/commit-step.mjs" 5
git push -u origin feat/quan-auth-users-5commits
```

Chỉ chuyển bước sau khi bước trước thành công. Bạn tự chạy lệnh push sau khi review; các lệnh trên không được chạy tự động khi đọc tài liệu. Mở một PR cho nhánh, tiếp tục push các commit vào PR đó. Merge bằng **Create a merge commit**, tránh squash để giữ 5 commit.

Mỗi commit cần được chính thành viên đọc, kiểm thử và giải thích. Các patch giữ nội dung source có AI hỗ trợ; không mô tả là lịch sử làm việc đã xảy ra. Test/evidence có sẵn trong tài liệu là kết quả của lần bàn giao cũ; không tự nhận đó là kết quả trên máy mình.
