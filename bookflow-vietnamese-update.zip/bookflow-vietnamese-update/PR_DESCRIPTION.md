## Problem and resulting behavior

The website previously displayed its interface only in English. This change adds
an English/Vietnamese selector in the header, including on mobile, and remembers
an explicit choice across reloads. Switching preserves the session, form drafts,
filters and page while translating navigation, forms, feedback and administration.
Dates follow the selected locale and retain Vietnam time.

## Contract and data

No API, database schema, migration or dependency changes. Book/user content and
machine-readable IDs, enum values and audit action codes remain unchanged. Only
the language preference is stored in localStorage; authentication tokens remain
in memory. Unknown API error details retain their original text.

## Validation

Cloud validation of the prepared patch: `npm run check` passed (66 server and
80 client tests; existing React lint warnings remain). `npm run test:e2e` passed
24 desktop/mobile cases. The same borrowing/return contract runs in English on
desktop and Vietnamese on mobile. The public language flow checks switching,
form preservation, validation, reload persistence and mobile overflow.

- [x] `npm run check` on cloud
- [x] Relevant E2E checks on cloud
- [x] Loading/empty/error and role-specific UI labels translated
- [x] No real credentials, session tokens or raw browser traces included
- [ ] Validation on the submitting member's Mac
- [ ] Another team member reviewed

AI assistance is documented in `docs/AI_ASSISTANCE.md`.
