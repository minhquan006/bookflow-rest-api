# Bàn giao các phần BookFlow

Đề tài 1 — RESTful Web Services, môn 503073. Source ghép trong workspace giữ
backend và giao diện public Catalog thật của Tú, bổ sung Auth/staff screens và
Loans. Xem [README](../README.md), [contract](API_CONTRACT.md),
[kiểm chứng](FULL_VALIDATION.md) và [blueprint](PROJECT_BLUEPRINT.md).

## Phạm vi và lịch sử thành viên

| Thành viên                  | Phụ trách                     | Bàn giao                                                                                        |
| --------------------------- | ----------------------------- | ----------------------------------------------------------------------------------------------- |
| Nguyễn Minh Quân — 52400227 | Auth/Users, nền tảng/tích hợp | Đã push `feat/auth-users`, mốc `f33bd6b`; Quân review phần mình                                 |
| Phạm Văn Tú — 52400252      | Catalog/Copies và UI          | Giữ nhánh `feat/catalog` tại `1bdf367`; nhận bundle giữ lịch sử và patch bổ sung trên nhánh mới |
| Lê Nguyễn Vạn An — 52400258 | Loans/Dashboard/Audit và UI   | `loans.patch` cho An review/test/sửa rồi tự commit; áp dụng sau Catalog                         |

Chỉ nhánh Auth/Users của Quân đã được push trong đợt chuẩn bị này. Phần Tú/An
được đóng gói để người phụ trách tiếp nhận; không push hoặc force push thay họ.
Code/test có AI hỗ trợ. Người nhận cần đọc, chạy, điều chỉnh và giải thích được
phần tiếp nhận. Không thay author/date để tạo lịch sử đóng góp giả; mỗi người
vẫn viết tài liệu và trình bày module mình.

## Gói Tú giữ mã và commit hiện có

`catalog-base.bundle` chứa merge local `0901559`, có cha là Auth `f33bd6b` và
Catalog thật `1bdf367`; bundle yêu cầu có lịch sử main nền móng `6b2404c`.
Merge nền đã hòa giải điểm giao nhau ở App/server/test. `catalog.patch` là phần
bổ sung từ merge nền tới `e182809`: facade ghép router, authenticated client,
staff category/book/copy screens, xử lý412 và test. Backend Catalog và các public
components của Tú tiếp tục được dùng, không thay bằng một module viết lại.

Sau khi Quân merge Auth vào main và Tú lưu mọi công việc local, đọc hướng dẫn
trong gói. Các lệnh chính, chạy trong repository và thay path bằng thư mục gói:

```bash
git fetch origin
git bundle verify /path/to/catalog-base.bundle
git fetch /path/to/catalog-base.bundle delivery/catalog-base:refs/heads/review/catalog-base
git merge-base --is-ancestor origin/main review/catalog-base
git merge-base --is-ancestor origin/feat/catalog review/catalog-base
git switch -c feat/catalog-integration review/catalog-base
git apply --check /path/to/catalog.patch
git apply /path/to/catalog.patch
```

Chỉ chạy tiếp nếu từng lệnh thành công. Hai kiểm tra ancestor thường không in
gì khi đạt. Nếu main hoặc nhánh Tú đã có commit mới, dừng để cập nhật/hòa giải
gói; không xóa phần mới hoặc bỏ qua kiểm tra. Nhánh `feat/catalog` cũ giữ nguyên.
Sau review/test, dùng `git add --pathspec-from-file=/path/to/FILES.txt` để stage
đúng toàn bộ patch, xem diff rồi tự commit và push `feat/catalog-integration`.
Tú/Quân chọn PR tích hợp; không merge đồng thời hai PR Catalog khác nhau.

## Gói An và thứ tự tích hợp

**Auth → Catalog thật của Tú + phần bổ sung → Loans/Dashboard/Audit → regression.**

`loans.patch` có base là tree Catalog `e182809`. An đợi Auth và Catalog merge
vào main, lấy main mới và tạo nhánh `feat/loans` hoặc một tên mới nếu tên đó đã
được dùng. Kiểm tra patch trước khi áp dụng:

```bash
git status --short
git switch main
git pull --ff-only origin main
git switch -c feat/loans
git apply --check /path/to/loans.patch
git apply /path/to/loans.patch
npm run check
npm run test:integration
npm run test:e2e
```

Cài dependencies/config/DB theo README nếu máy chưa chuẩn bị. Raw `git diff`
patch không tự commit và không dùng `git am`. Nếu check lỗi vì phần review của
Tú đổi source, hòa giải có chủ đích và chạy lại test; không force/reset công
việc local. `FILES.txt` của gói An bao gồm cả script benchmark, Postman, docs,
App/router và test; đọc diff trước khi stage rồi commit bằng Git identity của An.
Không gửi `.env`, token, dependency folders hoặc DB dump trong gói.

Tú review Auth, An review Catalog và Quân review Loans. Sau merge, chạy toàn bộ
check, PostgreSQL integration, browser, Postman và Docker. Kết quả local không
thay kết quả CI của commit merge hoặc kiểm tra máy thành viên thứ hai.

## Nội dung cần hiểu và nghiệm thu

- **Quân:** strict register luôn MEMBER; Argon2id; JWT signature/issuer/audience/
  expiry; role/status đọc DB; refresh hash/rotation/reuse; Origin/CSRF; logout;
  last-admin race; token RAM và khôi phục phiên.
- **Tú:** SQL tham số hóa/sort allowlist; category/book/copy constraints;
  search/filter/page; archived visibility; condition so với availability;
  ETag/304, If-Match 428/412 và stale update; barcode unique; archive/borrow race;
  không đổi condition của copy đang mượn; public components cũ vẫn hoạt động.
- **An:** user → book → copy → loan lock order; hạn mức/overdue/duplicate;
  copy cuối; rollback loan+audit; return idempotency với copy → loan order;
  ownership 404; dashboard staff/audit ADMIN; không tự retry POST loan khi kết quả
  không rõ; không lộ loan cũ khi đổi tài khoản trên UI.

Controller giữ HTTP, service giữ nghiệp vụ/transaction, repository nhận cùng
DB client. Không import backend source vào client hoặc xen `pool.query()` trong
transaction. Chỉ thêm migration mới; không sửa checksum đã merge. DB test riêng
kết thúc `_test`; không reset DB dev.

Mỗi PR ghi hành vi mới, endpoints/schema đổi, test đã/chưa chạy, ảnh thật khi
đổi UI và một người khác review. Không push main thay review. Kiểm tra CI và
branch protection trên GitHub riêng.

## Bài nộp còn lại

Hạn Quân cung cấp: **30/10/2026**, chưa có giờ cụ thể. Yêu cầu giảng viên đã cung
cấp chỉ là `503073-Midterm-V1.docx`; không tự đặt thêm ràng buộc LMS.

- Chạy checkout sạch trên máy thứ hai, lưu lỗi/cách khắc phục thật.
- Hoàn thiện báo cáo tiếng Anh Word/PDF 20–60 trang phần nội dung theo mẫu Khoa;
  slide và video tiếng Anh có âm thanh tối đa 20 phút, đủ ba người.
- Mẫu Khoa được đề tham chiếu nhưng chưa nhận; thông tin giảng viên và giờ nộp
  cần xác nhận trước khi xuất bộ nộp cuối.
- Lưu ảnh/log/benchmark không chứa secret; không dùng mockup/số giả làm chứng cứ.
  Phân công báo cáo/video giữ theo mục 27 blueprint.

Xem [REQUIREMENTS_TRACEABILITY](REQUIREMENTS_TRACEABILITY.md). Hoàn thành source
không đồng nghĩa hoàn thành báo cáo/video hoặc bảo đảm mức điểm.
