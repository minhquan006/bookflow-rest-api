# Trạng thái triển khai và tích hợp

Source tích hợp local giữ Auth/Users của Quân, Catalog hiện có của Tú và phần
Loans/Dashboard/Audit cho An. Đây là trạng thái của tree được kiểm thử, không
đồng nghĩa mọi phần đã merge vào main.

| Gói                   | Phụ trách       | Nội dung                                                                                                   | Bàn giao                                                                         |
| --------------------- | --------------- | ---------------------------------------------------------------------------------------------------------- | -------------------------------------------------------------------------------- |
| Auth/Users            | Quân — 52400227 | Register/login, JWT, refresh rotation/reuse, CSRF, logout, users/RBAC và UI                                | Đã push `feat/auth-users`, mốc `f33bd6b`; cần review/merge                       |
| Catalog/Copies        | Tú — 52400252   | Giữ backend Books/Categories/Copies và public UI ở `1bdf367`; thêm Auth client, staff UI, ETag/412 và test | Bundle nền giữ lịch sử + patch bổ sung; Tú review/test/sửa rồi tự push nhánh mới |
| Loans/Dashboard/Audit | An — 52400258   | Borrow/return, locking, hạn mức/overdue, dashboard/audit và UI                                             | Patch riêng sau Catalog; An review/test/sửa rồi tự commit/push                   |

Merge local `0901559` có hai nguồn Auth `f33bd6b` và Catalog thật `1bdf367`.
Phần Catalog bổ sung được chuẩn bị tại `e182809`. Gói Tú dùng
`catalog-base.bundle` chứa merge nền, rồi áp `catalog.patch` từ `0901559` đến
`e182809`; gói An bắt đầu từ tree Catalog này. Các commit local chuẩn bị bàn giao
không được push lên nhánh của Tú/An bởi Quân.

Quy trình: review/merge Auth → Tú nhận bundle/patch và review Catalog → merge
Catalog → An áp patch và review Loans → regression/CI và chạy trên máy thứ hai.
Không force push nhánh `feat/catalog` đang có; nếu nhánh đã đi tiếp sau mốc đóng
gói, phải hòa giải phần mới trước khi áp dụng. Xem [TEAM_HANDOFF](TEAM_HANDOFF.md)
và [FULL_VALIDATION](FULL_VALIDATION.md).

Code/test có AI hỗ trợ. Commit không thay thế việc đọc mã, kiểm thử, thay đổi có
ý nghĩa và trình bày phần mình. Hạn Quân xác nhận: **30/10/2026**, chưa có giờ cụ
thể. Đề chính thức là `503073-Midterm-V1.docx`; báo cáo Word/PDF, slide và video
vẫn cần cả nhóm hoàn thiện bằng kết quả thật.
